package com.example.myapppetloja

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
